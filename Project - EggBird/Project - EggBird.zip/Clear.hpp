#ifndef _CLS_
#define _CLS_

#include <stdlib.h>

void Cls(){
    system("cls");//clear console
}

#endif